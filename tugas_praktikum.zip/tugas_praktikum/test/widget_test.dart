import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:tugas_praktikum/main.dart';

void main() {
  testWidgets('Widget test example', (WidgetTester tester) async {

    await tester.pumpWidget(MyApp());

   
    expect(find.text('Welcome Back'), findsOneWidget);

    final emailField = find.byType(TextField).first;
    await tester.enterText(emailField, 'test@example.com');
    expect(find.text('test@example.com'), findsOneWidget);

   
    final passwordField = find.byType(TextField).at(1);
    await tester.enterText(passwordField, 'password123');
    expect(find.text('password123'), findsOneWidget);

    final loginButton = find.text('Log In');
    await tester.tap(loginButton);
    await tester.pump(); 
  });
}