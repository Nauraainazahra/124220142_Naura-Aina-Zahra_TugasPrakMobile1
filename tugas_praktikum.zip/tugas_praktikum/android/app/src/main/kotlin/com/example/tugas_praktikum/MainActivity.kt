package com.example.tugas_praktikum

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
